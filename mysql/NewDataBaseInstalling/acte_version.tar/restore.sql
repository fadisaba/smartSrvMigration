--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.2
-- Dumped by pg_dump version 10.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.acte_version DROP CONSTRAINT acte_version_pkey;
ALTER TABLE public.acte_version ALTER COLUMN "acteVersionId" DROP DEFAULT;
DROP SEQUENCE public."acte_version_acteVersionId_seq";
DROP TABLE public.acte_version;
SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: acte_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.acte_version (
    "acteVersionId" integer NOT NULL,
    "acteVersionCode" character varying(255) NOT NULL,
    "acteVersionStartDate" date NOT NULL,
    "acteVersionEndDate" character varying(255),
    active boolean DEFAULT true,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public.acte_version OWNER TO postgres;

--
-- Name: acte_version_acteVersionId_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."acte_version_acteVersionId_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."acte_version_acteVersionId_seq" OWNER TO postgres;

--
-- Name: acte_version_acteVersionId_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."acte_version_acteVersionId_seq" OWNED BY public.acte_version."acteVersionId";


--
-- Name: acte_version acteVersionId; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acte_version ALTER COLUMN "acteVersionId" SET DEFAULT nextval('public."acte_version_acteVersionId_seq"'::regclass);


--
-- Data for Name: acte_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.acte_version ("acteVersionId", "acteVersionCode", "acteVersionStartDate", "acteVersionEndDate", active, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public.acte_version ("acteVersionId", "acteVersionCode", "acteVersionStartDate", "acteVersionEndDate", active, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/2636.dat';

--
-- Name: acte_version_acteVersionId_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."acte_version_acteVersionId_seq"', 1, false);


--
-- Name: acte_version acte_version_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acte_version
    ADD CONSTRAINT acte_version_pkey PRIMARY KEY ("acteVersionId");


--
-- PostgreSQL database dump complete
--

