--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.2
-- Dumped by pg_dump version 10.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.acte_other DROP CONSTRAINT acte_other_pkey;
ALTER TABLE public.acte_other ALTER COLUMN "acteOtherId" DROP DEFAULT;
DROP SEQUENCE public."acte_other_acteOtherId_seq";
DROP TABLE public.acte_other;
SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: acte_other; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.acte_other (
    "acteOtherId" integer NOT NULL,
    "acteOtherName" character varying(255) NOT NULL,
    "acteOtherCode" character varying(255),
    "acteOtherAmount" character varying(255) NOT NULL,
    "acteOtherIsNgap" boolean,
    active boolean DEFAULT true,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone,
    "acteOtherStartDate" date,
    "acteOtherEndDate" date
);


ALTER TABLE public.acte_other OWNER TO postgres;

--
-- Name: acte_other_acteOtherId_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."acte_other_acteOtherId_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."acte_other_acteOtherId_seq" OWNER TO postgres;

--
-- Name: acte_other_acteOtherId_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."acte_other_acteOtherId_seq" OWNED BY public.acte_other."acteOtherId";


--
-- Name: acte_other acteOtherId; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acte_other ALTER COLUMN "acteOtherId" SET DEFAULT nextval('public."acte_other_acteOtherId_seq"'::regclass);


--
-- Data for Name: acte_other; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.acte_other ("acteOtherId", "acteOtherName", "acteOtherCode", "acteOtherAmount", "acteOtherIsNgap", active, "createdAt", "updatedAt", "deletedAt", "acteOtherStartDate", "acteOtherEndDate") FROM stdin;
\.
COPY public.acte_other ("acteOtherId", "acteOtherName", "acteOtherCode", "acteOtherAmount", "acteOtherIsNgap", active, "createdAt", "updatedAt", "deletedAt", "acteOtherStartDate", "acteOtherEndDate") FROM '$$PATH$$/2637.dat';

--
-- Name: acte_other_acteOtherId_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."acte_other_acteOtherId_seq"', 198, true);


--
-- Name: acte_other acte_other_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acte_other
    ADD CONSTRAINT acte_other_pkey PRIMARY KEY ("acteOtherId");


--
-- PostgreSQL database dump complete
--

